
- Team Lembur :     

1. Annisah Fithri - 211401029
2. Fatihannisa Listy Zulmi - 211401034
3. Fanny Faujannah - 211401125
4. Yogi Noviana - 211401137
5. Addina Nabilah Siregar - 211401140
