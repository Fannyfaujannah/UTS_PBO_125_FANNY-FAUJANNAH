/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package posproject;

/**
 *
 * @author Asus
 */
public class PosProject {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        LoginForm login = new LoginForm();
        login.setVisible(true);
    }
    
}
